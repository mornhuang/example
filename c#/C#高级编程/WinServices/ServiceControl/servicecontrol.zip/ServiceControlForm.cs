namespace Wrox.ProfessionalCSharp
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;
    using System.Data;
    using System.ServiceProcess;

    /// <summary>
    ///    Summary description for Form1.
    /// </summary>
    public class ServiceControlForm : System.WinForms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
        private System.WinForms.Button buttonRefresh;
        private System.WinForms.Button buttonExit;
        private System.WinForms.Button buttonContinue;
        private System.WinForms.Button buttonPause;
        private System.WinForms.Button buttonStop;
        private System.WinForms.Button buttonStart;
        private System.WinForms.TextBox textBoxServiceName;
        private System.WinForms.TextBox textBoxServiceType;
        private System.WinForms.TextBox textBoxServiceStatus;
        private System.WinForms.TextBox textBoxDisplayName;
        private System.WinForms.ListBox listBoxServices;
        private System.ServiceProcess.ServiceController[] services;

        public ServiceControlForm()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            RefreshServiceList();
        }

        protected void RefreshServiceList()
        {
            services = ServiceController.GetServices();
            listBoxServices.DataSource = services;
            listBoxServices.DisplayMember = "DisplayName";
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container ();
            this.buttonContinue = new System.WinForms.Button ();
            this.buttonStart = new System.WinForms.Button ();
            this.buttonExit = new System.WinForms.Button ();
            this.listBoxServices = new System.WinForms.ListBox ();
            this.textBoxServiceType = new System.WinForms.TextBox ();
            this.textBoxServiceName = new System.WinForms.TextBox ();
            this.textBoxDisplayName = new System.WinForms.TextBox ();
            this.buttonRefresh = new System.WinForms.Button ();
            this.textBoxServiceStatus = new System.WinForms.TextBox ();
            this.buttonPause = new System.WinForms.Button ();
            this.buttonStop = new System.WinForms.Button ();
            //@this.TrayHeight = 0;
            //@this.TrayLargeIcon = false;
            //@this.TrayAutoArrange = true;
            buttonContinue.Location = new System.Drawing.Point (408, 160);
            buttonContinue.Size = new System.Drawing.Size (96, 24);
            buttonContinue.TabIndex = 8;
            buttonContinue.Enabled = false;
            buttonContinue.Text = "Continue";
            buttonContinue.Click += new System.EventHandler (this.buttonContinue_Click);
            buttonStart.Location = new System.Drawing.Point (296, 120);
            buttonStart.Size = new System.Drawing.Size (96, 24);
            buttonStart.TabIndex = 5;
            buttonStart.Enabled = false;
            buttonStart.Text = "Start";
            buttonStart.Click += new System.EventHandler (this.buttonStart_Click);
            buttonExit.Location = new System.Drawing.Point (408, 224);
            buttonExit.Size = new System.Drawing.Size (96, 24);
            buttonExit.TabIndex = 10;
            buttonExit.Text = "Exit";
            buttonExit.Click += new System.EventHandler (this.buttonExit_Click);
            listBoxServices.Location = new System.Drawing.Point (16, 16);
            listBoxServices.Size = new System.Drawing.Size (256, 238);
            listBoxServices.TabIndex = 0;
            listBoxServices.SelectedIndexChanged += new System.EventHandler (this.OnSelectedIndexChanged);
            textBoxServiceType.Location = new System.Drawing.Point (296, 64);
            textBoxServiceType.TabIndex = 3;
            textBoxServiceType.Size = new System.Drawing.Size (208, 20);
            textBoxServiceName.Location = new System.Drawing.Point (296, 88);
            textBoxServiceName.TabIndex = 4;
            textBoxServiceName.Size = new System.Drawing.Size (208, 20);
            textBoxDisplayName.Location = new System.Drawing.Point (296, 16);
            textBoxDisplayName.TabIndex = 1;
            textBoxDisplayName.Size = new System.Drawing.Size (208, 20);
            buttonRefresh.Location = new System.Drawing.Point (296, 224);
            buttonRefresh.Size = new System.Drawing.Size (96, 24);
            buttonRefresh.TabIndex = 9;
            buttonRefresh.Text = "Refresh";
            buttonRefresh.Click += new System.EventHandler (this.buttonRefresh_Click);
            textBoxServiceStatus.Location = new System.Drawing.Point (296, 40);
            textBoxServiceStatus.TabIndex = 2;
            textBoxServiceStatus.Size = new System.Drawing.Size (208, 20);
            buttonPause.Location = new System.Drawing.Point (296, 160);
            buttonPause.Size = new System.Drawing.Size (96, 24);
            buttonPause.TabIndex = 7;
            buttonPause.Enabled = false;
            buttonPause.Text = "Pause";
            buttonPause.Click += new System.EventHandler (this.buttonPause_Click);
            buttonStop.Location = new System.Drawing.Point (408, 120);
            buttonStop.Size = new System.Drawing.Size (96, 24);
            buttonStop.TabIndex = 6;
            buttonStop.Enabled = false;
            buttonStop.Text = "Stop";
            buttonStop.Click += new System.EventHandler (this.buttonStop_Click);
            this.Text = "Wrox Service Control";
            this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
            this.ClientSize = new System.Drawing.Size (512, 273);
            this.Controls.Add (this.buttonRefresh);
            this.Controls.Add (this.buttonExit);
            this.Controls.Add (this.buttonContinue);
            this.Controls.Add (this.buttonPause);
            this.Controls.Add (this.buttonStop);
            this.Controls.Add (this.buttonStart);
            this.Controls.Add (this.textBoxServiceName);
            this.Controls.Add (this.textBoxServiceType);
            this.Controls.Add (this.textBoxServiceStatus);
            this.Controls.Add (this.textBoxDisplayName);
            this.Controls.Add (this.listBoxServices);
        }

        protected void buttonContinue_Click (object sender, System.EventArgs e)
        {

        }

        protected void buttonPause_Click (object sender, System.EventArgs e)
        {

        }

        protected void buttonExit_Click (object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        protected void buttonRefresh_Click (object sender, System.EventArgs e)
        {
            RefreshServiceList();
        }

        protected void buttonStop_Click (object sender, System.EventArgs e)
        {
            ServiceController controller = (ServiceController)listBoxServices.SelectedItem;
            controller.Stop();
            controller.WaitForStatus(ServiceControllerStatus.Stopped, new TimeSpan(0, 0, 30));
            int index = listBoxServices.SelectedIndex;
            RefreshServiceList();
            listBoxServices.SelectedIndex = index;
        }

        protected void buttonStart_Click (object sender, System.EventArgs e)
        {
            ServiceController controller = (ServiceController)listBoxServices.SelectedItem;
            controller.Start();
            controller.WaitForStatus(ServiceControllerStatus.Running, new TimeSpan(0, 0, 30));
            int index =listBoxServices.SelectedIndex;
            RefreshServiceList();
            listBoxServices.SelectedIndex = index;
        }

        protected string GetServiceTypeName(ServiceType type)
        {
            string serviceType = "";
            if ((type & ServiceType.InteractiveProcess) != 0)
            {
                serviceType = "Interactive ";
                type -= ServiceType.InteractiveProcess;
            }
            switch (type)
            {
                case ServiceType.Adapter:
                    serviceType += "Adapter";
                    break;
                case ServiceType.FileSystemDriver:
                case ServiceType.KernelDriver:
                case ServiceType.RecognizerDriver:
                    serviceType += "Driver";
                    break;
                case ServiceType.Win32OwnProcess:
                    serviceType += "Win32 Service Process";
                    break;
                case ServiceType.Win32ShareProcess:
                    serviceType += "Win32 Shared Process";
                    break;
                default:
                    serviceType += "unknown type " + type.ToString();
                    break;
            }
            return serviceType;
        }

        protected void SetServiceStatus(ServiceController controller)
        {
            buttonStart.Enabled = true;
            buttonStop.Enabled = true;
            buttonPause.Enabled = true;
            buttonContinue.Enabled = true;

            if (!controller.CanPauseAndContinue)
            {
                buttonPause.Enabled = false;
                buttonContinue.Enabled = false;
            }
            if (!controller.CanStop)
            {
                buttonStop.Enabled = false;
            }

            ServiceControllerStatus status = controller.Status;
            switch (status)
            {
                case ServiceControllerStatus.ContinuePending:
                    textBoxServiceStatus.Text = "Continue Pending";
                    buttonContinue.Enabled = false;
                    break;
                case ServiceControllerStatus.Paused:
                    textBoxServiceStatus.Text = "Paused";
                    buttonPause.Enabled = false;
                    break;
                case ServiceControllerStatus.PausePending:
                    textBoxServiceStatus.Text = "Pause Pending";
                    buttonPause.Enabled = false;
                    break;
                case ServiceControllerStatus.StartPending:
                    textBoxServiceStatus.Text = "Start Pending";
                    buttonStart.Enabled = false;                    
                    break;
                case ServiceControllerStatus.Running:
                    textBoxServiceStatus.Text = "Running";
                    buttonStart.Enabled = false;
                    break;
                case ServiceControllerStatus.Stopped:
                    textBoxServiceStatus.Text = "Stopped";
                    buttonStop.Enabled = false;
                    break;
                case ServiceControllerStatus.StopPending:
                    textBoxServiceStatus.Text = "Stop Pending";
                    buttonStop.Enabled = false;
                    break;
                default:
                    textBoxServiceStatus.Text = "Unknown status";
                    break;
            }            
        }

        protected void OnSelectedIndexChanged (object sender, System.EventArgs e)
        {
            ServiceController controller = (ServiceController)listBoxServices.SelectedItem;
            textBoxDisplayName.Text = controller.DisplayName;
            textBoxServiceType.Text = GetServiceTypeName(controller.ServiceType);
            textBoxServiceName.Text = controller.ServiceName;

            SetServiceStatus(controller);
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
            Application.Run(new ServiceControlForm());
        }
    }
}
