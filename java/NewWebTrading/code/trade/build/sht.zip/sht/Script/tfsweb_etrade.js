function test() {
  alert('loaded');
}
