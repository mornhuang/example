//Shielding the button of mouse
$(document).bind("contextmenu",function(e){return false;});
