less.js
=======

The **dynamic** stylesheet language.

<http://lesscss.org>

about
-----

This is the JavaScript, and now official, stable version of LESS.

For more information on the language and usage visit [lesscss.org](http://lesscss.org). More information also available [in our wiki](https://github.com/cloudhead/less.js/wiki)

license
-------

See `LICENSE` file.

> Copyright (c) 2009-2013 Alexis Sellier & The Core Less Team
