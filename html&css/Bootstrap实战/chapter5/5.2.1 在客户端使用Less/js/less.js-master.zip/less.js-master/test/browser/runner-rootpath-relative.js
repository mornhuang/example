less.rootpath = "https://www.github.com/cloudhead/less.js/";
less.relativeUrls = true;
describe("less.js browser test - rootpath and relative url's", function() {
    testLessEqualsInDocument();
});